var navList = document.getElementById("menu");

function Show() {
navList.classList.add("Show_m");
}

function Hide(){
navList.classList.remove("Show_m");
}